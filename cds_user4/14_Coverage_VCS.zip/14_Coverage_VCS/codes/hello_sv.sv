module hello;

initial begin
$display("==========================");
$display("Hello World from System Verilog");
$display("==========================");

$finish;
end

endmodule
